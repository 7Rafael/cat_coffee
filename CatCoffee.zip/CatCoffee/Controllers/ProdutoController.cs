﻿using Microsoft.AspNetCore.Mvc;

namespace CatCoffee.Controllers
{
    public class ProdutoController : Controller
    {
        public IActionResult Index()
        {

            return View();
        }
    }
}
